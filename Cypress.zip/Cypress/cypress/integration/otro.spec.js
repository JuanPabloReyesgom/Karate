// otro.spec.js created with Cypress
//
// Start writing your Cypress tests below!
// If you're unfamiliar with how Cypress works,
// check out the link below and learn how to write your first test:
// https://on.cypress.io/writing-first-test

/// <reference types="cypress" />

describe ('Prueba Inditex', function() {
 
    it ('Comprobar en que año se hizo el primer proceso automatico', function (){
        
        //Entramos a google
        cy.visit('http://www.tous.com/')
        cy.get('.cta-container > .button > .btn > .text').click()
        
          

        
    })

})
