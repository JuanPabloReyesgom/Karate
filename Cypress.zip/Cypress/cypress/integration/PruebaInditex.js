/// <reference types="cypress" />

describe ('Prueba Inditex', function() {
 
    it ('Comprobar en que año se hizo el primer proceso automatico', function (){
        
        //Entramos a google
        cy.visit('http://google.com/')
        //Validamos el paso
        cy.get('.lnXdpd').should('be.visible')
        // Aceptamos las condiciones
        cy.get('#L2AGLb > .QS5gu').click()
        cy.get('.gLFyf').type('automatización{enter}')
        cy.get('[href="https://es.wikipedia.org/wiki/Automatizaci%C3%B3n_industrial"] > .LC20lb').click()
        //valide que esta ubicado en la wikipedia
        cy.get('.mw-wiki-logo').should('be.visible')
        cy.get('body').screenshot()
        //Validamos que aparece el año del primer proceso automatizado
        cy.get('.mw-parser-output > :nth-child(15)').should('be.visible').contains('1801').screenshot()
          

        
    })

})