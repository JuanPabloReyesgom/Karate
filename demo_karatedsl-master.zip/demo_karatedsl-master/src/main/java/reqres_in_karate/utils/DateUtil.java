package reqres_in_karate.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class DateUtil {

    private static final Logger logger = LoggerFactory.getLogger(DateUtil.class);

    //timestamp.feature --> Capture a timestamp
    public static String getDate(){
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

        String dateString = format.format(new Date());
        logger.debug("date: {}", dateString);
        return dateString;
    }

    //timestamp.feature --> Capture a year old date
    public static String getSubtractedYear(){
        DateTimeFormatter format = DateTimeFormatter.ofPattern("uuuu-MM-dd");
        LocalDate localDate = LocalDate.parse(getDate(), format);
        localDate = localDate.minusMonths(12);
        String dateString =  localDate.format(format);
        logger.debug("One year ago is: {}", dateString);
        return dateString;
    }


}
