package examples;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.List;

public class TraerData {

    String name;
    String salida ="";
    String json ;

    public TraerData(String aa) {
        this.json = aa;
        procedimiento();
    }

    public void procedimiento() {
        Type type = new TypeToken<List<TraerData>>() {}.getType();
        List<TraerData> inpList = new Gson().fromJson(json, type);

        for (int i = 0; i < inpList.size(); i++) {
            String sup = inpList.get(i).name;
            int contador = 0;
            for (int j = 0; j < inpList.size(); j++){
                String inf = inpList.get(j).name;
                if(sup != null && inf != null) {
                    if(sup.equals(inf)){
                        contador = contador+1;
                    }
                }

            }
            salida += "{\""+sup+"\": "+contador+"}";
        }
    }

    public String getPersonalizado() {
        return salida;
    }

}