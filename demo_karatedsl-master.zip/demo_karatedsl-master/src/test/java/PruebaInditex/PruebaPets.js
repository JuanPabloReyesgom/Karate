function fn(){
    class Pets {

        constructor(pets) {
            this.pets = pets;
        }

        identificar(){
            var identificados= [];
            var data = this.pets;
            for (var i = 0; i < data.length; i++){
                var contador = 0;
                for (var j = 0; j < data.length; j++){
                    if(data[i]['name'] == data[j]['name']){
                        contador = contador+1;
                    }
                }
                identificados.push({
                    'name' : data[i]['name'],
                    'cantidad' : contador
                });
            }
            return identificados
        }
    }

    const arr = [{id : "#string" , name : "doggie"} , {id : "#string" , name : "bruno"} , {id : "#string" , name : "bruno"} , {id : "#string" , name : "aa"} , {id : "#string" , name : "aa"}]
    const pet = new Pets(arr);
    pet.identificar();
}